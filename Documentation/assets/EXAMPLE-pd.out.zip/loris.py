import pd
try:
    import loristrck
except ImportError:
    pd.error("Loris is not installed")
    pd.error("Install loristrck using the message 'run loristrck'")
    
def lorisAnalisys(audiofile, parcialnumber):
    audiopathname = pd.home() + '/' + audiofile
    samples, sr = loristrck.util.sndreadmono(audiopathname)
    partials = loristrck.analyze(samples, sr, resolution=30, windowsize=40, 
                      hoptime=1/120)
    selected, noise = loristrck.util.select(partials, mindur=0.02, maxfreq=12000, 
                            minamp=-60,)

    parcialnumber = int(parcialnumber)
    pdPartial = []
    for partial in selected:
        sec2ms = int(partial[parcialnumber][0] * 1000)
        try:
            pdPartial.append(sec2ms)
            pdPartial.append(partial[parcialnumber][1])
            pdPartial.append(partial[parcialnumber][2])
            pdPartial.append(partial[parcialnumber][3])
            pd.out(pdPartial)
            pdPartial = []
        except:
            pd.out([sec2ms, 0, 0, 0])
    pd.print("Done")

    

    
