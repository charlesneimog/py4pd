import pd

pd.print("submodule was loaded")
